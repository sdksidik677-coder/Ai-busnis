require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 30 }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    app: "SDK AI BUSINESS",
    aiConfigured: Boolean(process.env.OPENAI_API_KEY),
    productSearchConfigured: Boolean(process.env.SERPAPI_KEY),
    note: "Marketplace access depends on each provider's API permissions and credentials."
  });
});

function clean(value, max = 4000) {
  return String(value ?? "").trim().slice(0, max);
}

app.post("/api/generate", async (req, res) => {
  const { type, product, details, platform, tone } = req.body || {};
  const allowed = ["description", "promotion", "seo", "ideas", "store"];
  if (!allowed.includes(type)) return res.status(400).json({ error: "Jenis generator tidak dikenal." });
  if (!clean(product, 500)) return res.status(400).json({ error: "Masukkan nama produk atau topik terlebih dahulu." });
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "AI belum aktif. Isi OPENAI_API_KEY di file .env, lalu jalankan ulang server." });
  }

  const prompts = {
    description: "Buat deskripsi produk e-commerce berbahasa Indonesia yang jelas, menarik, jujur, dan siap ditempel ke marketplace. Jangan mengarang spesifikasi, sertifikasi, garansi, atau klaim yang tidak diberikan. Tandai informasi yang belum tersedia sebagai [lengkapi].",
    promotion: "Buat paket promosi produk berbahasa Indonesia: 3 hook, caption, ajakan bertindak, dan 8 hashtag relevan. Hindari klaim berlebihan dan jangan menjanjikan viral atau penjualan.",
    seo: "Buat 5 judul produk SEO marketplace, kata kunci utama, kata kunci pendukung, dan alasan singkat. Jangan melakukan keyword stuffing.",
    ideas: "Berikan 10 ide pengembangan atau bundling produk yang realistis, target pembeli, dan cara menguji minat pasar dengan biaya rendah. Jangan mengklaim ide pasti laku.",
    store: "Buat 10 nama toko yang mudah diingat, tagline, dan konsep identitas merek. Hindari menyatakan nama tersedia secara hukum atau domain."
  };

  const userText = [
    "Tugas: " + prompts[type],
    "Produk/topik: " + clean(product, 500),
    "Detail faktual yang diberikan: " + clean(details, 3000),
    "Platform tujuan: " + clean(platform, 100),
    "Gaya bahasa: " + clean(tone, 100)
  ].join("\n");

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: "Kamu adalah asisten bisnis e-commerce Indonesia. Jawab praktis, terstruktur, faktual, dan dalam bahasa Indonesia." },
          { role: "user", content: userText }
        ],
        temperature: 0.7
      })
    });
    const data = await response.json();
    if (!response.ok) {
      const message = data?.error?.message || "Permintaan AI gagal.";
      return res.status(response.status === 401 ? 503 : 502).json({ error: message });
    }
    const output = data?.choices?.[0]?.message?.content;
    if (!output) return res.status(502).json({ error: "AI tidak mengembalikan hasil." });
    res.json({ ok: true, output });
  } catch (err) {
    res.status(502).json({ error: "Tidak dapat menghubungi layanan AI. Periksa koneksi internet dan coba lagi." });
  }
});

app.get("/api/research", async (req, res) => {
  const q = clean(req.query.q, 180);
  if (!q) return res.status(400).json({ error: "Masukkan kata kunci produk." });
  if (!process.env.SERPAPI_KEY) {
    return res.status(503).json({ error: "Pencarian web produk belum aktif. Isi SERPAPI_KEY di .env. Alternatif: impor CSV penjualan toko sendiri." });
  }
  try {
    const url = new URL("https://serpapi.com/search.json");
    url.searchParams.set("engine", "google_shopping");
    url.searchParams.set("q", q);
    url.searchParams.set("gl", "id");
    url.searchParams.set("hl", "id");
    url.searchParams.set("api_key", process.env.SERPAPI_KEY);
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok || data.error) return res.status(502).json({ error: data.error || "Penyedia pencarian produk gagal." });
    const items = (data.shopping_results || []).slice(0, 20).map((item, index) => ({
      id: index + 1,
      title: item.title || "Produk tanpa judul",
      price: item.price || "Harga tidak tersedia",
      source: item.source || "Sumber tidak disebutkan",
      rating: item.rating ?? null,
      reviews: item.reviews ?? null,
      link: item.link || "",
      thumbnail: item.thumbnail || ""
    }));
    res.json({
      ok: true,
      query: q,
      source: "Google Shopping melalui SerpApi",
      dataType: "Hasil listing dan sinyal minat, bukan angka penjualan marketplace",
      warning: "Harga, rating, dan ulasan adalah data listing yang ditemukan. Ini bukan bukti jumlah unit terjual atau ranking penjualan seluruh marketplace.",
      items
    });
  } catch {
    res.status(502).json({ error: "Pencarian gagal. Periksa koneksi dan konfigurasi SerpApi." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, "0.0.0.0", () => console.log(`SDK AI BUSINESS berjalan di http://localhost:${PORT}`));
