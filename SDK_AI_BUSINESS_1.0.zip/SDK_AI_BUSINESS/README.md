# SDK AI BUSINESS 1.0

## Kebutuhan
- Android dengan Acode
- Node.js tersedia di terminal (atau lingkungan Node lain)
- Koneksi internet
- API key OpenAI untuk generator AI
- API key SerpApi untuk pencarian listing Google Shopping (opsional, layanan pihak ketiga berbayar sesuai paketnya)

## Jalankan
1. Ekstrak ZIP ke folder yang mudah ditemukan.
2. Buka folder `SDK_AI_BUSINESS` di Acode.
3. Salin `.env.example` menjadi `.env`.
4. Isi `OPENAI_API_KEY` dan bila punya `SERPAPI_KEY`.
5. Buka terminal di folder proyek, jalankan `npm install`.
6. Jalankan `npm start`.
7. Buka browser HP ke `http://127.0.0.1:3000`.

Jika Acode tidak menyediakan Node.js, jalankan folder ini pada lingkungan Node.js seperti Termux. Acode adalah editor; ia tidak otomatis menjadi server hosting publik.

## API keys
- OPENAI_API_KEY: buat dari dashboard API OpenAI. Penggunaan API dapat dikenakan biaya terpisah dari langganan ChatGPT.
- SERPAPI_KEY: buat dari akun SerpApi. Pencarian Google Shopping menunjukkan listing yang ditemukan, bukan angka unit terjual marketplace.

Jangan pernah menaruh API key di `public/app.js`, HTML, atau membagikan file `.env`. File `.env` hanya dibaca server.

## Fitur
- AI deskripsi produk, promosi, SEO, ide bisnis, nama toko.
- Riset listing Google Shopping melalui SerpApi bila API key diatur.
- Analisis CSV penjualan secara lokal di browser.
- Pemeriksaan status konfigurasi.

## Format CSV
Header wajib: `product_name,sales_count`
Header opsional: `revenue,price`

Contoh:
```csv
product_name,sales_count,revenue,price
Botol stainless,120,6000000,50000
Rak dapur,75,3750000,50000
```

## Batasan penting
- Belum ada konektor otomatis untuk semua marketplace.
- Setiap marketplace memerlukan API resmi/akses partner dan izin yang sesuai. Tambahkan konektor hanya setelah dokumentasi dan kredensial resmi tersedia.
- Hasil Google Shopping adalah data listing publik dan sinyal pasar, bukan bukti produk paling laku.
- Peringkat unit terjual hanya dihitung dari CSV penjualan yang kamu unggah.
- Jangan gunakan scraping yang melanggar ketentuan layanan marketplace.
- Server lokal hanya dapat diakses dari perangkat/jaringan yang sesuai. Agar punya link publik, deploy ke hosting Node.js dan aktifkan HTTPS.
