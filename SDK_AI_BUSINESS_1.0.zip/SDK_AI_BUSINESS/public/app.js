const $ = (id) => document.getElementById(id);
const titles = {home:"Dashboard",writer:"AI Content Studio",research:"Riset Produk",csv:"Analisis Data CSV"};
function showPage(name){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("show",p.id===name));document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.page===name));$("pageTitle").textContent=titles[name]||"Dashboard";window.scrollTo(0,0)}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));

async function checkHealth(){try{const r=await fetch("/api/health");const d=await r.json();$("apiStatus").textContent=`AI ${d.aiConfigured?"siap":"belum diatur"} · Riset ${d.productSearchConfigured?"siap":"belum diatur"}`;}catch{$("apiStatus").textContent="Server tidak terhubung";}}
checkHealth();

$("generateBtn").addEventListener("click",async()=>{
 const btn=$("generateBtn");const product=$("product").value.trim();
 if(!product){$("genResult").textContent="Masukkan nama produk atau topik terlebih dahulu.";return;}
 btn.disabled=true;btn.textContent="Sedang membuat…";$("genResult").textContent="Menghubungi layanan AI…";
 try{const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:$("genType").value,product,details:$("details").value,platform:$("platform").value,tone:$("tone").value})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Gagal membuat hasil.");$("genResult").textContent=d.output;}
 catch(e){$("genResult").textContent="Belum berhasil: "+e.message;}
 finally{btn.disabled=false;btn.textContent="✦ Buat dengan AI";}
});
$("copyResult").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("genResult").textContent);$("copyResult").textContent="Tersalin ✓";setTimeout(()=>$("copyResult").textContent="Salin hasil",1500);}catch{$("copyResult").textContent="Salin manual";}});

$("searchBtn").addEventListener("click",async()=>{
 const q=$("researchQuery").value.trim();if(!q){$("researchMeta").textContent="Masukkan kata kunci produk.";return;}
 const btn=$("searchBtn");btn.disabled=true;btn.textContent="Mencari…";$("researchResults").innerHTML="";$("researchMeta").textContent="Sedang mencari listing produk…";
 try{const r=await fetch("/api/research?q="+encodeURIComponent(q));const d=await r.json();if(!r.ok)throw new Error(d.error||"Pencarian gagal.");$("researchMeta").textContent=`Sumber: ${d.source}. ${d.dataType}. ${d.warning}`;
 if(!d.items.length){$("researchResults").textContent="Belum ada hasil. Coba kata kunci lain.";return;}
 d.items.forEach(item=>{const el=document.createElement("article");el.className="product";if(item.thumbnail){const img=document.createElement("img");img.src=item.thumbnail;img.alt="";img.loading="lazy";el.appendChild(img);}const info=document.createElement("div");const h=document.createElement("h4");h.textContent=item.title;const p=document.createElement("p");p.textContent=`${item.price} · ${item.source} · Rating: ${item.rating??"—"} · Ulasan: ${item.reviews??"—"}`;info.append(h,p);if(item.link){const a=document.createElement("a");a.href=item.link;a.target="_blank";a.rel="noopener noreferrer";a.textContent="Lihat listing";info.append(a);}el.appendChild(info);$("researchResults").appendChild(el);});
 }catch(e){$("researchMeta").textContent=e.message;}finally{btn.disabled=false;btn.textContent="Cari produk";}
});

function parseCSV(text){
 const rows=[];let row=[],cell="",quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'&&quoted&&n==='"'){cell+='"';i++;}else if(c==='"'){quoted=!quoted;}else if(c===','&&!quoted){row.push(cell);cell="";}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&n==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell="";}else cell+=c;}
 row.push(cell);if(row.some(x=>x.trim()))rows.push(row);return rows;
}
$("analyzeCsv").addEventListener("click",async()=>{
 const file=$("csvFile").files[0];if(!file){$("csvOutput").textContent="Pilih file CSV terlebih dahulu.";return;}
 try{
 const rows=parseCSV(await file.text());if(rows.length<2)throw new Error("CSV tidak berisi data.");
 const headers=rows.shift().map(x=>x.trim().toLowerCase());const nameIndex=headers.indexOf("product_name");const salesIndex=headers.indexOf("sales_count");const revenueIndex=headers.indexOf("revenue");
 if(nameIndex<0||salesIndex<0)throw new Error("Kolom wajib: product_name dan sales_count. Kolom opsional: revenue, price.");
 const map=new Map();for(const row of rows){const name=(row[nameIndex]||"").trim();const sales=Number((row[salesIndex]||"0").replace(/[^\d.-]/g,""));const revenue=revenueIndex>=0?Number((row[revenueIndex]||"0").replace(/[^\d.-]/g,"")):0;if(!name||!Number.isFinite(sales))continue;const old=map.get(name)||{name,sales:0,revenue:0};old.sales+=sales;old.revenue+=Number.isFinite(revenue)?revenue:0;map.set(name,old);}
 const ranked=[...map.values()].sort((a,b)=>b.sales-a.sales);if(!ranked.length)throw new Error("Tidak ditemukan baris penjualan yang valid.");
 $("csvOutput").innerHTML="";const heading=document.createElement("h3");heading.textContent="Peringkat berdasarkan jumlah terjual dalam file";$("csvOutput").appendChild(heading);
 ranked.slice(0,20).forEach((item,i)=>{const line=document.createElement("div");line.className="rank";const left=document.createElement("span");left.textContent=`${i+1}. ${item.name}`;const right=document.createElement("b");right.textContent=`${item.sales.toLocaleString("id-ID")} unit`;line.append(left,right);$("csvOutput").appendChild(line);if(item.revenue){const small=document.createElement("small");small.className="muted";small.textContent="Omzet: Rp "+item.revenue.toLocaleString("id-ID");line.appendChild(small);}});
 const note=document.createElement("p");note.className="muted";note.textContent="Analisis ini hanya mewakili data pada file yang kamu unggah, bukan seluruh marketplace."; $("csvOutput").appendChild(note);
 }catch(e){$("csvOutput").textContent="Tidak dapat membaca CSV: "+e.message;}
});